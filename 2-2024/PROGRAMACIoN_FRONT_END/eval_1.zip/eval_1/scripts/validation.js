// scripts/validacion.js

function validarFormulario() {
 
    return true;
}

const botonEnviar = document.getElementById('enviar');
botonEnviar.addEventListener('click', validarFormulario);
